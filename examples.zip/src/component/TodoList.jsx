import React from "react";
function TodoList(props) {

    return <li> {props.text} </li>
    
   
}
export default TodoList; 