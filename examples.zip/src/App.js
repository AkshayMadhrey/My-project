import './App.css';
import React from 'react'
import AllInOne from './component/AllInOne';
//import Header from './component/Header';
// import Body from './component/Body';
// import Calculator from './component/Calculator'


function App() {

  return (
    <div>
      {/* <Header />
         <Body />  */}
      <AllInOne />
      {/* <Calculator /> */}
     
    </div>
  );
}

export default App;